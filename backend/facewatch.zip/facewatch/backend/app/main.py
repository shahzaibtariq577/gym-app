"""FaceWatch REST API (FastAPI). Run with:  uvicorn app.main:app --port 8000"""
import os
import threading
from contextlib import asynccontextmanager
from datetime import datetime
from typing import List

import cv2
from fastapi import Body, FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles

from . import storage as st
from .engine import Engine, StartError

st.init_dirs()
cfg = st.load_settings()
engine = Engine(cfg)
engine.reload_people()


@asynccontextmanager
async def lifespan(_app):
    def boot():
        engine.load_models()
        if engine.models_ready and cfg["autostart"] and engine.people and cfg["source_mode"] != "video":
            try:
                engine.start()
            except StartError:
                pass
    threading.Thread(target=boot, daemon=True).start()
    yield
    engine.stop()
    st.save_settings(cfg)


app = FastAPI(title="FaceWatch", version="5.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
                   allow_methods=["*"], allow_headers=["*"])
app.mount("/snapshots", StaticFiles(directory=st.MATCH_DIR), name="snapshots")


# ----------------------------------------------------------------- control
@app.get("/api/status")
def status():
    return engine.status()


@app.post("/api/start")
def start():
    try:
        engine.start()
    except StartError as e:
        raise HTTPException(400, str(e))
    return engine.status()


@app.post("/api/stop")
def stop():
    engine.stop()
    return engine.status()


@app.get("/api/stream")
def stream():
    if not engine.running:
        raise HTTPException(409, "Not watching.")
    return StreamingResponse(engine.frames(), media_type="multipart/x-mixed-replace; boundary=frame",
                             headers={"Cache-Control": "no-store"})


# ---------------------------------------------------------------- settings
@app.get("/api/settings")
def get_settings():
    return cfg


@app.put("/api/settings")
def put_settings(patch: dict = Body(...)):
    cfg.update(st.clean_settings(patch))
    st.save_settings(cfg)
    return cfg


@app.get("/api/cameras")
def cameras():
    if engine.running:
        raise HTTPException(409, "Stop watching first, then scan.")
    found = []
    for i in range(4):
        try:
            cap = cv2.VideoCapture(i)
            if cap.isOpened():
                found.append(i)
            cap.release()
        except Exception:
            pass
    return {"cameras": found}


# ------------------------------------------------------------------ people
def _changed():
    engine.reload_people()


@app.get("/api/people")
def people():
    return st.people_summary()


@app.post("/api/people", status_code=201)
async def add_person(name: str = Form(...), files: List[UploadFile] = File(...)):
    clean = st.safe_name(name)
    if not clean:
        raise HTTPException(400, "Please use letters or numbers in the name.")
    clean = st.find_person(clean) or clean
    added = st.add_photos(clean, [await f.read() for f in files])
    if not added:
        raise HTTPException(400, "Could not read the selected image(s).")
    _changed()
    return {"name": clean, "added": added}


@app.post("/api/people/{name}/photos", status_code=201)
async def add_photos(name: str, files: List[UploadFile] = File(...)):
    real = st.find_person(st.safe_name(name))
    if not real:
        raise HTTPException(404, "Person not found.")
    added = st.add_photos(real, [await f.read() for f in files])
    if not added:
        raise HTTPException(400, "Could not read the selected image(s).")
    _changed()
    return {"name": real, "added": added}


@app.delete("/api/people/{name}", status_code=204)
def remove_person(name: str):
    real = st.find_person(st.safe_name(name))
    if not real:
        raise HTTPException(404, "Person not found.")
    st.remove_person(real)
    _changed()
    return Response(status_code=204)


@app.get("/api/people/{name}/thumb")
def thumb(name: str):
    real = st.find_person(st.safe_name(name))
    data = st.thumbnail(real) if real else None
    if data is None:
        raise HTTPException(404, "No photo.")
    return Response(data, media_type="image/jpeg", headers={"Cache-Control": "no-cache"})


# ------------------------------------------------------------------ alerts
def _row(r):
    return {"id": r["id"], "time": r["time"].strftime(st.TIME_FMT), "name": r["name"],
            "score": r["score"], "snapshot": r["snapshot"], "source": r["source"]}


@app.get("/api/alerts")
def alerts(limit: int = 15):
    rows = st.read_log()
    return [_row(r) for r in reversed(rows[-max(1, min(limit, 500)):])]


@app.delete("/api/alerts", status_code=204)
def clear_alerts():
    st.clear_log()
    return Response(status_code=204)


@app.get("/api/dashboard")
def dashboard():
    rows = st.read_log()
    today = datetime.now().date()
    todays = [r for r in rows if r["time"].date() == today]
    hourly = [0] * 24
    for r in todays:
        hourly[r["time"].hour] += 1

    stats = {}
    for r in rows:
        s = stats.setdefault(r["name"], {"today": 0, "total": 0, "last": None})
        s["total"] += 1
        if r["time"].date() == today:
            s["today"] += 1
        if s["last"] is None or r["time"] > s["last"]:
            s["last"] = r["time"]
    names = sorted({p["name"] for p in st.people_summary()} | set(stats))
    by_person = [{"name": n, "today": stats.get(n, {}).get("today", 0),
                  "total": stats.get(n, {}).get("total", 0),
                  "last": stats[n]["last"].strftime(st.TIME_FMT) if n in stats else None} for n in names]

    last = max(rows, key=lambda r: r["time"]) if rows else None
    return {
        "today": len(todays), "total": len(rows), "people": engine.people_count,
        "last": {"time": last["time"].strftime(st.TIME_FMT), "name": last["name"]} if last else None,
        "hourly": hourly, "by_person": by_person,
        "history": [_row(r) for r in reversed(rows[-300:])],
    }


# --------------------------------------------- serve the built React app
DIST = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                    "frontend", "dist")
if os.path.isdir(DIST):
    app.mount("/assets", StaticFiles(directory=os.path.join(DIST, "assets")), name="assets")

    @app.get("/{path:path}", include_in_schema=False)
    def spa(path: str):
        f = os.path.join(DIST, path)
        return FileResponse(f if path and os.path.isfile(f) else os.path.join(DIST, "index.html"))
