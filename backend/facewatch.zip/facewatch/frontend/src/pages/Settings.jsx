import { useState } from "react";
import { api } from "../api.js";

const INTERVALS = [[5, "Every 5 seconds"], [10, "Every 10 seconds"], [30, "Every 30 seconds"],
                   [60, "Every minute"], [300, "Every 5 minutes"]];

export default function Settings({ settings: s, onChange, running }) {
  const [cams, setCams] = useState([0, 1]);
  const [scanMsg, setScanMsg] = useState("");

  const scan = async () => {
    setScanMsg("Scanning...");
    try {
      const { cameras } = await api.cameras();
      setCams(cameras.length ? cameras : [0]);
      setScanMsg(cameras.length ? `Found ${cameras.length}` : "No camera found");
    } catch (e) { setScanMsg(e.message); }
  };

  const check = (k, label) => (
    <label className="check"><input type="checkbox" checked={s[k]} onChange={(e) => onChange({ [k]: e.target.checked })} />{label}</label>
  );

  return (
    <section>
      <header className="head"><h2>Settings</h2></header>

      <div className="card setgroup">
        <h3>Detection</h3>
        <label className="range">Match strictness: <b>{s.threshold.toFixed(2)}</b>
          <input type="range" min="0.30" max="0.75" step="0.01" value={s.threshold}
                 onChange={(e) => onChange({ threshold: parseFloat(e.target.value) })} />
        </label>
        <p className="muted">Higher is stricter. If someone who only looks similar gets flagged, raise it. If the real person is missed, lower it.</p>
        {check("autostart", "Start watching automatically when the backend starts")}
        {check("auto_reconnect", "Reconnect automatically if the camera drops")}
      </div>

      <div className="card setgroup">
        <h3>Alerts</h3>
        <label>Alert again while the person stays in view
          <select value={s.alert_interval} onChange={(e) => onChange({ alert_interval: +e.target.value })}>
            {INTERVALS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </select>
        </label>
        {check("beep", "Play a beep in this browser")}
        {check("snapshots", "Save a snapshot picture with each alert")}
      </div>

      <div className="card setgroup">
        <h3>Video source</h3>
        {running && <p className="note">Source changes apply the next time you press Start.</p>}
        <label className="check"><input type="radio" name="mode" checked={s.source_mode === "webcam"} onChange={() => onChange({ source_mode: "webcam" })} />Webcam</label>
        {s.source_mode === "webcam" && (
          <div className="row sub">
            <select value={s.cam_index} onChange={(e) => onChange({ cam_index: +e.target.value })}>
              {[...new Set([...cams, s.cam_index])].sort().map((i) => <option key={i} value={i}>Camera {i}</option>)}
            </select>
            <button className="btn" onClick={scan} disabled={running}>Scan cameras</button>
            <span className="muted">{scanMsg}</span>
          </div>
        )}
        <label className="check"><input type="radio" name="mode" checked={s.source_mode === "video"} onChange={() => onChange({ source_mode: "video" })} />Video file on the backend computer</label>
        {s.source_mode === "video" && (
          <input className="sub" placeholder="C:\Videos\clip.mp4" value={s.video_path} onChange={(e) => onChange({ video_path: e.target.value })} />
        )}
        <label className="check"><input type="radio" name="mode" checked={s.source_mode === "network"} onChange={() => onChange({ source_mode: "network" })} />Network camera (phone app, IP camera, RTSP)</label>
        {s.source_mode === "network" && (
          <>
            <input className="sub" placeholder="rtsp://user:pass@192.168.1.20/stream" value={s.url} onChange={(e) => onChange({ url: e.target.value })} />
            <p className="muted sub">Example: http://192.168.1.5:8080/video. Passwords are hidden in the log and the Live page.</p>
          </>
        )}
      </div>
    </section>
  );
}
