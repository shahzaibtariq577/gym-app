import { useEffect, useState } from "react";
import { api, formatTime, snapshotUrl } from "../api.js";

function Hourly({ data }) {
  const max = Math.max(1, ...data);
  const bw = 480 / 24;
  return (
    <svg viewBox="0 0 480 150" className="chart" role="img" aria-label="Alerts per hour today">
      <line x1="0" y1="124" x2="480" y2="124" stroke="var(--line)" />
      {data.map((n, i) => {
        const h = n ? Math.max(4, (n / max) * 96) : 0;
        return (
          <g key={i}>
            {n > 0 && <>
              <rect x={i * bw + 4} y={124 - h} width={bw - 8} height={h} rx="2" fill="var(--teal)" />
              <text x={i * bw + bw / 2} y={119 - h} textAnchor="middle" fontSize="10" fill="var(--ink)">{n}</text>
            </>}
            {i % 3 === 0 && (
              <text x={i * bw + bw / 2} y="141" textAnchor="middle" fontSize="10" fill="var(--muted)">
                {String(i).padStart(2, "0")}
              </text>
            )}
          </g>
        );
      })}
    </svg>
  );
}

export default function Dashboard({ alertSeq }) {
  const [d, setD] = useState(null);
  const [selected, setSelected] = useState(null);
  const [err, setErr] = useState("");

  const load = () => api.dashboard().then(setD).catch((e) => setErr(e.message));
  useEffect(() => { load(); }, [alertSeq]);
  useEffect(() => {
    const id = setInterval(load, 5000);
    return () => clearInterval(id);
  }, []);

  const clear = async () => {
    if (!window.confirm("Delete the alert history? Snapshot pictures are kept.")) return;
    await api.clearAlerts();
    setSelected(null);
    load();
  };

  if (!d) return <p className="muted">{err || "Loading..."}</p>;
  const sel = d.history.find((r) => r.id === selected);

  return (
    <section>
      <header className="head">
        <h2>Dashboard</h2>
        <button className="btn" onClick={clear}>Clear history</button>
      </header>

      <div className="stats">
        <div className="card stat"><span>Alerts today</span><b>{d.today}</b></div>
        <div className="card stat"><span>Total alerts</span><b>{d.total}</b></div>
        <div className="card stat"><span>People tracked</span><b>{d.people}</b></div>
        <div className="card stat">
          <span>Last alert</span>
          <b className="small">{d.last ? `${formatTime(d.last.time, false)} ${d.last.name}` : "none yet"}</b>
        </div>
      </div>

      <div className="grid2">
        <div className="card"><h3>Alerts per hour today</h3><Hourly data={d.hourly} /></div>
        <div className="card">
          <h3>By person</h3>
          <table>
            <thead><tr><th>Person</th><th>Today</th><th>Total</th><th>Last seen</th></tr></thead>
            <tbody>
              {d.by_person.length === 0 && <tr><td colSpan="4" className="muted">No people yet.</td></tr>}
              {d.by_person.map((p) => (
                <tr key={p.name}><td>{p.name}</td><td>{p.today}</td><td>{p.total}</td><td>{formatTime(p.last)}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid2">
        <div className="card">
          <h3>Alert history, newest first</h3>
          <div className="scroll">
            <table className="clickable">
              <thead><tr><th>Time</th><th>Person</th><th>Score</th><th>Source</th></tr></thead>
              <tbody>
                {d.history.length === 0 && <tr><td colSpan="4" className="muted">No alerts yet.</td></tr>}
                {d.history.map((r) => (
                  <tr key={r.id} className={r.id === selected ? "sel" : ""} tabIndex={0}
                      onClick={() => setSelected(r.id)}
                      onKeyDown={(e) => e.key === "Enter" && setSelected(r.id)}>
                    <td>{formatTime(r.time)}</td><td>{r.name}</td><td>{r.score}</td><td>{r.source}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <div className="card">
          <h3>Snapshot</h3>
          {!sel && <p className="muted">Select an alert to see its snapshot.</p>}
          {sel && (sel.snapshot
            ? <img className="snap" src={snapshotUrl(sel.snapshot)} alt={`Snapshot of ${sel.name}`} />
            : <p className="muted">No snapshot was saved for this alert.</p>)}
        </div>
      </div>
    </section>
  );
}
